CONTROLES :

d�placement : ZQSD
munitions : 123
tir : clic gauche

MUNITIONS :

neutrophile : 1 : d�truit les bact�ries.
monocyte : 2 : marque les autres types de menaces.
lymphocyte : 3 : d�truit les menaces marqu�es.